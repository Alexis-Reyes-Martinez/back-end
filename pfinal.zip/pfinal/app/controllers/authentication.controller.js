import bcryptsjs from "bcryptsjs";
import jsonwebtoken from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

export const usuarios = [{
    user: "admin1",
    email: "admin1@empresa.cl",
    password: "Password1"
}]


async function login(req,res){
    console.log(req.body);
    const user = req.body.user;
    const password = req.body.password;
    if(!user || !password){
        return res.status(400).send({status:"Error",message:"Campos incompletos"})
    }
    const usuarioArevisar = usuarios.find(usuario => usuario.user === user);
    if(!usuarioArevisar){
        return res.status(400).send({status:"Error",message:"Error de autenticación"})
    }
    const loginCorrecto = await bcryptsjs.compare(password,usuarioArevisar.password);
    if(!loginCorrecto){
        return res.status(400).send({status:"Error",message:"Error de autenticación"})
    }
    const token = jsonwebtoken.sign(
        {user:usuarioArevisar.user},
        process.env.JWT_SECRET,
        {expiresIn:process.env.JWT_EXPIRATION})

        const cookieOption = {
            expires: new Date(Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000),
            path: "/"
        }
       res.cookie("jwt",token,cookieOption);
       res.send({status:"OK",message:"Usario Atenticado",redirect:"/admin"})
}

async function register(req,res){
    const user = req.body.user;
    const password = req.body.password;
    const email = req.body.email;
    if(!user || !password || !email){
        return res.status(400).send({status:"Error",message:"Campos incompletos"})
    }
    const usuarioArevisar = usuarios.find(usuario => usuario.user === user);
    if(usuarioArevisar){
        return res.status(400).send({status:"Error",message:"Este usuario ya existe"})
    }
    const salt = await bcryptsjs.genSalt(5);
    const hashPassword = await bcryptsjs.hash(password,salt);
    const nuevoUsuario ={
        user, email, password: hashPassword
    }
    usuarios.push(nuevoUsuario);
    console.log(nuevoUsuario);    
    return res.status(201).send({status:"ok",message:`Usuario ${nuevoUsuario} Agregado`,redirect:"/"})
}

export const methods = {
    login,
    register
}